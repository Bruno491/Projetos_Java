package br.projetofinal.projeto.projeto_final.controllers;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import br.projetofinal.projeto.projeto_final.models.Usuarios;
import br.projetofinal.projeto.projeto_final.repository.UsuarioRepository;

@RestController
@RequestMapping("/usuario")
@CrossOrigin("*")
public class UsuarioController {
    @Autowired
    private UsuarioRepository repository;

    @PostMapping
    public Usuarios postMethodName(@RequestBody Usuarios usuarios){
        return repository.save(usuarios);
    }

    @GetMapping
    public Iterable<Usuarios> selecionar() {
        return repository.findAll();
    }

    @GetMapping("/selecionar/{id}")
    public Usuarios selecionar(@PathVariable int id) {
        return repository.selecionar(id);
    }

    @SuppressWarnings("rawtypes")
    @GetMapping("/autenticar/{email}/{senha}")
    public ResponseEntity autenticar(@PathVariable String email , @PathVariable String senha) {
        try {
            Usuarios usuario = repository.autenticar(email, senha);
            if(usuario!=null){
                return ResponseEntity.ok(usuario);
            }
            else{
                return ResponseEntity.badRequest().body("Dados Incorretos");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
