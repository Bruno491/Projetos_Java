
function App() {
  return (
    <div>
      Olá
    </div>
  );
}

export default App;
