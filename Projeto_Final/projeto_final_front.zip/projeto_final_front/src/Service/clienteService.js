import ApiService from "./apiService";

class ClienteService extends ApiService {
    constructor(){
        super('/usuario')
    }
    validarUsuario (email, senha){
        return this.get(`/autenticar/${email}/${senha}`)
    }
    
}
export default ClienteService;
